select 
    *
from  public.materialtype;