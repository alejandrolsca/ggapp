select 
    *
from  public.material
where mt_id = $1;