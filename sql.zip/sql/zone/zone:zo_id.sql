select 
    *
from  public.zone
where zo_id = $1;