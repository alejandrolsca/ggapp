insert into public.zone
(zo_jsonb)
values ($1);