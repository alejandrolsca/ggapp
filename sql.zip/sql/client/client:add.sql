insert into public.client
(cl_jsonb)
values ($1);