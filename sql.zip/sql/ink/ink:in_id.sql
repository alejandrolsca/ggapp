select 
    *
from  public.ink
where in_id = $1;