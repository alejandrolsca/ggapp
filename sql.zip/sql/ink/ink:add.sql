insert into public.ink
(in_jsonb)
values ($1);