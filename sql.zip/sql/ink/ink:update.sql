update public.ink
set in_jsonb = $1
where in_id = $2;