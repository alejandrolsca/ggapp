SELECT
	name as "countryName",
	geonameid as "geonameId"
FROM
	countryinfo
ORDER BY
	NAME ASC;