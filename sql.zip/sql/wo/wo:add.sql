insert into public.wo
(wo_jsonb)
values ($1);