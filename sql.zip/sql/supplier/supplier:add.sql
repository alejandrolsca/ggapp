insert into public.supplier
(su_jsonb)
values ($1);