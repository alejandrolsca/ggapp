select 
    *
from  public.supplier
where su_id = $1;