select 
    *
from  public.machine
where ma_id = $1;