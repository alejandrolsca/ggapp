insert into public.machine
(ma_jsonb)
values ($1);